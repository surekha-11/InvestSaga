// Check the source code for the questions
const wordList = [
    {
      word: "savings",
      hint: "This is money you set aside for future use. ",
    },
    {
      word: "portfolio",
      hint: "This shows the overall value of all your investments.",
    },
    
  ];
  