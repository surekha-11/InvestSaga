import scoreModel from "../models/scoreModel.js";

export const updateScoreController = async (req, res) => {
  try {
    const { userId,wordsearchScore} = req.body;

    // Fetch the user's current score document
    let userScore = await scoreModel.findOne({ userId });

    // If the user's score document doesn't exist, create a new one
    if (!userScore) {
      userScore = new scoreModel({ userId });
    }
    
    // Include other scores from the database in the request body
    const { learningScore, hangmanScore, triviaScore } = userScore;

    // Update the wordsearchScore in the score document
    userScore.wordsearchScore = wordsearchScore;

    // Calculate the finalScore based on the updated scores
    userScore.finalScore = learningScore + hangmanScore + wordsearchScore + triviaScore;

    // Save the updated score document
    await userScore.save();


    /*
    const updatedScore = await scoreModel.findOneAndUpdate(
      { userId },
      {
        learningScore,
        hangmanScore,
        wordsearchScore,
        triviaScore,
        finalScore: learningScore + hangmanScore + wordsearchScore + triviaScore
      },
      { new: true, upsert: true }
    );*/

    res.status(200).json({
      success: true,
      message: 'Score updated successfully',
      score: userScore
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: 'Error updating score',
      error: error.message
    });
  }
};

export const getGlobalScoreController = async (req, res) => {
  try {
    const userId = req.params.id;
    const globalScore = await scoreModel.findOne({ userId });
    
    if (!globalScore) {
      return res.status(404).json({
        success: false,
        message: 'Score not found'
      });
    }

    res.status(200).json({
      success: true,
      message: 'Global score retrieved successfully',
      globalScore
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: 'Error retrieving global score',
      error: error.message
    });
  }
};
