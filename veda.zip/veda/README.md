Gamification - Investment Journey<br>

backend:<br>
npm i express<br>
npm i nodemon<br>
npm i dotenv<br>
npm i mongoose <br>
npm i morgan <br>
npm i bcrypt<br>
npm i jsonwebtoken<br>
npm  i cors<br>
npm  i concurrently<br>

frontend:<br>
cd client<br>
npm i react-router-dom<br>
npm i react-icons<br>
npm i axios<br>
npm i react-hot-toast<br>

to run application<br>
npm run dev<br>
