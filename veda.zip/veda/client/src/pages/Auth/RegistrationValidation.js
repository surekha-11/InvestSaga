export const validateRegistrationForm = (name, email, password, phone, address, answer) => {
    const errors = {};
  
    if (!name.trim()) {
      errors.name = "Name is required";
    }
  
    if (!email.trim()) {
      errors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      errors.email = "Email is invalid";
    }
  
    if (!password.trim()) {
      errors.password = "Password is required";
    } else if (password.length < 6) {
      errors.password = "Password must be at least 6 characters long";
    }
  
    if (!phone.trim()) {
      errors.phone = "Phone is required";
    } 
    else if (!/^\d{10}$/.test(phone)) {
      errors.phone = "Phone number must be 10 digits";
    }
  
    
    if (!answer.trim()) {
      errors.answer = "Answer is required";
    }
  
    return errors;
  };
  