import React from 'react';

const WordList = () => {
  const wordList = [
    {
      word: "savings",
      hint: "This is money you set aside for future use."
    },
    {
      word: "portfolio",
      hint: "This shows the overall value of all your investments."
    },
    // Add more words as needed
  ];

  return wordList;
};

export default WordList;
