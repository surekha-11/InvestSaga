import Layout from "../../../components/Layout/Layout";
import "D:/investQuest-main/client/src/pages/games/Hangman/Hangmanstyle.css";
import React, { useState, useEffect } from 'react';


import hangman0 from 'D:/investQuest-main/client/src/images/hangman-0.svg';
import hangman1 from 'D:/investQuest-main/client/src/images/hangman-1.svg';
import hangman2 from 'D:/investQuest-main/client/src/images/hangman-2.svg';
import hangman3 from 'D:/investQuest-main/client/src/images/hangman-3.svg';
import hangman4 from 'D:/investQuest-main/client/src/images/hangman-4.svg';
import hangman5 from 'D:/investQuest-main/client/src/images/hangman-5.svg';
import hangman6 from 'D:/investQuest-main/client/src/images/hangman-6.svg';

const wordList = [
  { word: "savings", hint: "This is money you set aside for future use." },
  { word: "portfolio", hint: "This shows the overall value of all your investments." },
  { word: "jazz", hint: "A type of music." },
  // Add more words and hints as needed
];

function HangmanGame() {
  const [word, setWord] = useState('');
  const [hint, setHint] = useState('');
  const [guesses, setGuesses] = useState([]);
  const [chances, setChances] = useState(6);
  const [gameOver, setGameOver] = useState(false);

  useEffect(() => {
    startNewGame();
  }, []);

  const startNewGame = () => {
    const randomIndex = Math.floor(Math.random() * wordList.length);
    const selectedWord = wordList[randomIndex];
    setWord(selectedWord.word.toLowerCase());
    setHint(selectedWord.hint);
    setGuesses([]);
    setChances(6);
    setGameOver(false);
  };

  const handleGuess = (letter) => {
    if (!word.includes(letter)) {
      setChances(chances - 1);
    }
    setGuesses([...guesses, letter]);
  };

  const getWordDisplay = () => {
    return word
      .split('')
      .map(letter => (guesses.includes(letter) ? letter : '_'))
      .join(' ');
  };

  const getKeyboardButtons = () => {
    return Array.from(Array(26)).map((_, index) => {
      const letter = String.fromCharCode(97 + index);
      return (
        <button
          key={letter}
          onClick={() => handleGuess(letter)}
          disabled={guesses.includes(letter) || gameOver}
        >
          {letter}
        </button>
      );
    });
  };

  useEffect(() => {
    if (chances === 0) {
      setGameOver(true);
    }
    if (getWordDisplay() === word) {
      setGameOver(true);
    }
  }, [chances, word]);

  const hangmanImages = {
    6: hangman0,
    5: hangman1,
    4: hangman2,
    3: hangman3,
    2: hangman4,
    1: hangman5,
    0: hangman6,
  };

  return (
    <Layout>
      <div className="HangmanGame">
        <h1>Hangman Game</h1>
        <p>Hint: {hint}</p>
        <img src={hangmanImages[chances]} alt="Hangman" />
        <div className="Word-display">{getWordDisplay()}</div>
        <p>Incorrect Guesses: {6 - chances}/6</p>
        {gameOver && (
          <div>
            <p>{getWordDisplay() === word ? 'You win!' : 'You lose!'}</p>
            <button className="new-game" onClick={startNewGame}>New Game</button>
          </div>
        )}
        <div className="Keyboard">{getKeyboardButtons()}</div>
      </div>
    </Layout>
  );
}

export default HangmanGame;
