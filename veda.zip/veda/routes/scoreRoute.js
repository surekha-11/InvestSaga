import express from 'express';

import { requireSignIn } from '../middlewares/authMiddleware.js';
import { getGlobalScoreController, updateScoreController } from '../controllers/scoreController.js';

const router = express.Router();

router.put('/update-score', updateScoreController);
router.get('/global-score/:id', getGlobalScoreController);

export default router;